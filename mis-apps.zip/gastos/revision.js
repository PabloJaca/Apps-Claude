/* Revisión mensual con IA — añadido aparte, no toca el bundle de React.
   Lee los datos directamente de localStorage ("gastos-v1"), igual que hace
   la app de salud, comparte la misma clave de API guardada en este móvil
   (localStorage "salud-api-key") para no tener que pegarla dos veces. */

(function () {
  "use strict";

  var STORE_KEY = "gastos-v1";
  var API_KEY_STORE = "salud-api-key"; // misma clave que usa la app de salud
  var CACHE_KEY = "gastos-revisiones-v1";
  var MESES = ["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"];

  var C = {
    paper: "#F1F6FA", card: "#FFFFFF", ink: "#15293C", soft: "#7C93A8",
    line: "#E6EDF3", accent: "#0F9E8E", accentSoft: "#DFF3F0",
    mint: "#1FB47A", amber: "#F5A524", coral: "#F4614E", coralSoft: "#FDE4E0",
    shadow: "0 1px 2px rgba(21,41,60,.04), 0 6px 20px rgba(21,41,60,.055)",
  };

  function cargarDatos() {
    try {
      var raw = localStorage.getItem(STORE_KEY);
      if (!raw) return { gastos: [], fijos: [], categorias: [], presupuestoGlobal: null, presupuestosCat: {} };
      var d = JSON.parse(raw);
      return {
        gastos: d.gastos || [], fijos: d.fijos || [], categorias: d.categorias || [],
        presupuestoGlobal: d.presupuestoGlobal != null ? d.presupuestoGlobal : null,
        presupuestosCat: d.presupuestosCat || {},
      };
    } catch (e) { return { gastos: [], fijos: [], categorias: [], presupuestoGlobal: null, presupuestosCat: {} }; }
  }

  function pad(n) { return String(n).padStart(2, "0"); }

  function diasDelMes(ym) {
    var p = ym.split("-"); var y = +p[0], m = +p[1];
    return new Date(y, m, 0).getDate();
  }

  // combina gastos reales del mes + instancias generadas de gastos fijos activos ese mes
  function movimientosDelMes(datos, ym) {
    var nd = diasDelMes(ym);
    var fijosInstancias = (datos.fijos || [])
      .filter(function (o) { return o.desde <= ym && (!o.hasta || ym <= o.hasta); })
      .map(function (o) {
        var dia = Math.min(Math.max(1, o.dia || 1), nd);
        return { id: "fijo:" + o.id + ":" + ym, importe: o.importe, categoria: o.categoria, fecha: ym + "-" + pad(dia), nota: o.nombre, esFijo: true };
      });
    var reales = (datos.gastos || []).filter(function (g) { return (g.fecha || "").indexOf(ym) === 0; });
    return reales.concat(fijosInstancias);
  }

  function nombreCategoria(datos, id) {
    var c = (datos.categorias || []).find(function (c) { return c.id === id; });
    return c ? c.nombre : id;
  }

  function resumenMes(datos, ym) {
    var movs = movimientosDelMes(datos, ym);
    var total = movs.reduce(function (s, g) { return s + (Number(g.importe) || 0); }, 0);
    var fijoTotal = movs.filter(function (g) { return g.esFijo; }).reduce(function (s, g) { return s + (Number(g.importe) || 0); }, 0);
    var porCategoria = {};
    movs.forEach(function (g) {
      porCategoria[g.categoria] = (porCategoria[g.categoria] || 0) + (Number(g.importe) || 0);
    });
    var categorias = Object.keys(porCategoria).map(function (id) {
      return {
        id: id, nombre: nombreCategoria(datos, id),
        total: Math.round(porCategoria[id] * 100) / 100,
        presupuesto: datos.presupuestosCat && datos.presupuestosCat[id] != null ? datos.presupuestosCat[id] : null,
      };
    }).sort(function (a, b) { return b.total - a.total; });
    return {
      mes: ym, total: Math.round(total * 100) / 100,
      fijo: Math.round(fijoTotal * 100) / 100,
      variable: Math.round((total - fijoTotal) * 100) / 100,
      numMovimientos: movs.length,
      presupuestoGlobal: datos.presupuestoGlobal,
      categorias: categorias,
    };
  }

  function mesesAnteriores(ym, n) {
    var p = ym.split("-"); var y = +p[0], m = +p[1];
    var out = [];
    for (var i = 1; i <= n; i++) {
      m -= 1; if (m === 0) { m = 12; y -= 1; }
      out.push(y + "-" + pad(m));
    }
    return out;
  }

  function etiquetaMes(ym) {
    var p = ym.split("-");
    return MESES[+p[1] - 1] + " " + p[0];
  }

  function construirPrompt(datos, ym) {
    var actual = resumenMes(datos, ym);
    var anteriores = mesesAnteriores(ym, 6)
      .map(function (m) { return resumenMes(datos, m); })
      .filter(function (r) { return r.numMovimientos > 0; });
    return {
      actual: actual,
      anteriores: anteriores,
      etiquetaMes: etiquetaMes(ym),
    };
  }

  var SYS = "Analizas el registro personal de gastos de un adulto. Tono directo y sincero, basado en cifras, sin paternalismo ni frases motivacionales genéricas. Compara el mes actual con los meses anteriores que recibas (si no hay meses anteriores con datos, dilo y valora solo el mes actual). Ten en cuenta que 'fijo' son gastos recurrentes (alquiler, suscripciones) y 'variable' es todo lo demás. Español de España.\n" +
    "Devuelve SOLO este JSON, sin texto alrededor:\n" +
    '{"titular": "Máximo 12 palabras.", "valoracion": "3-4 frases sinceras con cifras concretas sobre cómo ha ido el mes.", "comparacion": "2-3 frases comparando con los meses anteriores recibidos, con cifras.", "mejoras": ["Mejora concreta 1, accionable y con datos.", "Mejora concreta 2.", "Mejora concreta 3."]}\n' +
    "Máximo 4 mejoras.";

  function getApiKey() { try { return localStorage.getItem(API_KEY_STORE) || ""; } catch (e) { return ""; } }
  function setApiKey(v) { try { v ? localStorage.setItem(API_KEY_STORE, v) : localStorage.removeItem(API_KEY_STORE); } catch (e) {} }

  function cargarCache() { try { return JSON.parse(localStorage.getItem(CACHE_KEY) || "{}"); } catch (e) { return {}; } }
  function guardarCache(c) { try { localStorage.setItem(CACHE_KEY, JSON.stringify(c)); } catch (e) {} }

  async function pedirRevision(datos, ym) {
    var key = getApiKey();
    if (!key) throw new Error("sin clave");
    var payload = construirPrompt(datos, ym);
    var res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1200,
        system: SYS,
        messages: [{ role: "user", content: "Datos del periodo:\n" + JSON.stringify(payload, null, 1) }],
      }),
    });
    if (!res.ok) throw new Error("API " + res.status);
    var data = await res.json();
    var texto = (data.content || []).map(function (b) { return b.type === "text" ? b.text : ""; }).join("\n")
      .replace(/```json/g, "").replace(/```/g, "").trim();
    var a = texto.indexOf("{"), b = texto.lastIndexOf("}");
    if (a === -1 || b === -1) throw new Error("respuesta no válida");
    return JSON.parse(texto.slice(a, b + 1));
  }

  /* ------------------------------------------------------------------- UI */

  function el(tag, style, attrs) {
    var e = document.createElement(tag);
    if (style) Object.assign(e.style, style);
    if (attrs) Object.keys(attrs).forEach(function (k) {
      if (k === "text") e.textContent = attrs[k];
      else if (k === "html") e.innerHTML = attrs[k];
      else e.setAttribute(k, attrs[k]);
    });
    return e;
  }

  function inyectarEstilos() {
    var s = document.createElement("style");
    s.textContent =
      "@import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,700;12..96,800&family=Instrument+Sans:wght@400;500;600&display=swap');" +
      ".rmg-fab{position:fixed;left:16px;bottom:16px;z-index:9998;border:none;border-radius:999px;padding:12px 16px;" +
      "background:" + C.accentSoft + ";color:" + C.accent + ";font-family:'Instrument Sans',sans-serif;font-weight:600;font-size:13.5px;" +
      "display:flex;align-items:center;gap:6px;box-shadow:" + C.shadow + ";cursor:pointer;}" +
      ".rmg-velo{position:fixed;inset:0;background:rgba(21,41,60,.42);z-index:9999;display:flex;align-items:flex-end;justify-content:center;}" +
      ".rmg-panel{background:" + C.paper + ";width:100%;max-width:480px;max-height:92vh;overflow:auto;border-radius:26px 26px 0 0;padding:20px 18px 28px;" +
      "font-family:'Instrument Sans',sans-serif;color:" + C.ink + ";animation:rmg-subir .22s cubic-bezier(.2,.8,.3,1) both;}" +
      "@keyframes rmg-subir{from{transform:translateY(24px);opacity:0}to{transform:none;opacity:1}}" +
      ".rmg-h1{font-family:'Bricolage Grotesque',sans-serif;font-weight:800;font-size:21px;letter-spacing:-.4px;margin:0;}" +
      ".rmg-card{background:" + C.card + ";border-radius:20px;box-shadow:" + C.shadow + ";padding:16px;margin-top:14px;}" +
      ".rmg-btn{border:none;border-radius:14px;padding:12px;font-family:'Instrument Sans',sans-serif;font-weight:600;font-size:13.5px;cursor:pointer;width:100%;}" +
      ".rmg-btn-primary{background:" + C.accent + ";color:#fff;}" +
      ".rmg-btn-soft{background:" + C.accentSoft + ";color:" + C.accent + ";}" +
      ".rmg-input{width:100%;border:1px solid " + C.line + ";border-radius:12px;padding:11px 12px;font-size:13.5px;font-family:monospace;box-sizing:border-box;}" +
      ".rmg-close{border:none;background:" + C.card + ";box-shadow:" + C.shadow + ";border-radius:14px;width:34px;height:34px;font-size:16px;color:" + C.soft + ";cursor:pointer;}" +
      ".rmg-mes{display:flex;align-items:center;justify-content:space-between;margin:14px 0 4px;}" +
      ".rmg-mes button{border:none;background:" + C.card + ";box-shadow:" + C.shadow + ";border-radius:12px;width:34px;height:34px;color:" + C.soft + ";cursor:pointer;font-size:15px;}" +
      ".rmg-p{font-size:13.5px;line-height:1.55;color:" + C.ink + ";margin:6px 0 0;}" +
      ".rmg-mid{color:" + C.soft + ";font-size:12.5px;line-height:1.5;}" +
      ".rmg-li{display:flex;gap:8px;margin-top:8px;font-size:13.5px;line-height:1.45;}" +
      ".rmg-dot{width:6px;height:6px;border-radius:99px;background:" + C.accent + ";margin-top:6px;flex-shrink:0;}" +
      ".rmg-spin{width:22px;height:22px;border:2.5px solid " + C.line + ";border-top-color:" + C.accent + ";border-radius:99px;animation:rmg-girar .7s linear infinite;margin:22px auto;}" +
      "@keyframes rmg-girar{to{transform:rotate(360deg)}}";
    document.head.appendChild(s);
  }

  var estado = { ym: null, datos: null, cache: null };

  function mesActualCerrado() {
    var hoy = new Date();
    var y = hoy.getFullYear(), m = hoy.getMonth() + 1; // mes en curso
    m -= 1; if (m === 0) { m = 12; y -= 1; } // mes anterior, ya cerrado
    return y + "-" + pad(m);
  }

  function abrirPanel() {
    estado.datos = cargarDatos();
    estado.cache = cargarCache();
    if (!estado.ym) estado.ym = mesActualCerrado();
    render();
  }

  function cerrarPanel() {
    var velo = document.querySelector(".rmg-velo");
    if (velo) velo.remove();
  }

  function cambiarMes(delta) {
    var p = estado.ym.split("-"); var y = +p[0], m = +p[1];
    m += delta; if (m === 0) { m = 12; y -= 1; } if (m === 13) { m = 1; y += 1; }
    var hoy = new Date(), max = hoy.getFullYear() + "-" + pad(hoy.getMonth() + 1);
    var candidato = y + "-" + pad(m);
    if (candidato > max) return;
    estado.ym = candidato;
    render();
  }

  function render() {
    cerrarPanel();
    var velo = el("div", null, { class: "rmg-velo" });
    velo.addEventListener("click", function (e) { if (e.target === velo) cerrarPanel(); });
    var panel = el("div", null, { class: "rmg-panel" });
    velo.appendChild(panel);
    document.body.appendChild(velo);

    var header = el("div", { display: "flex", alignItems: "center", justifyContent: "space-between" });
    header.appendChild(el("h1", null, { class: "rmg-h1", text: "Revisión mensual" }));
    var cerrar = el("button", null, { class: "rmg-close", text: "✕" });
    cerrar.addEventListener("click", cerrarPanel);
    header.appendChild(cerrar);
    panel.appendChild(header);

    var nav = el("div", null, { class: "rmg-mes" });
    var izq = el("button", null, { text: "‹" });
    izq.addEventListener("click", function () { cambiarMes(-1); });
    var etiqueta = el("span", { fontWeight: "700", fontFamily: "'Bricolage Grotesque',sans-serif" }, { text: etiquetaMes(estado.ym) });
    var der = el("button", null, { text: "›" });
    der.addEventListener("click", function () { cambiarMes(1); });
    nav.appendChild(izq); nav.appendChild(etiqueta); nav.appendChild(der);
    panel.appendChild(nav);

    var key = getApiKey();
    if (!key) { renderSinClave(panel); return; }

    var cacheado = estado.cache[estado.ym];
    if (cacheado) { renderResultado(panel, cacheado, true); return; }

    renderPedir(panel);
  }

  function renderSinClave(panel) {
    var card = el("div", null, { class: "rmg-card" });
    card.appendChild(el("p", { fontWeight: "700", fontSize: "15px" }, { text: "Clave de Claude" }));
    card.appendChild(el("p", null, {
      class: "rmg-mid",
      text: "Necesaria para que la app genere la revisión sola. La sacas en console.anthropic.com y se guarda solo en este móvil (la comparte con la app de Salud si ya la tenías puesta allí).",
    }));
    var input = el("input", null, { class: "rmg-input", type: "password", placeholder: "sk-ant-...", autocomplete: "off" });
    card.appendChild(input);
    var guardar = el("button", { marginTop: "10px" }, { class: "rmg-btn rmg-btn-primary", text: "Guardar clave" });
    guardar.addEventListener("click", function () {
      setApiKey(input.value.trim());
      render();
    });
    card.appendChild(guardar);
    panel.appendChild(card);

    var alt = el("div", null, { class: "rmg-card" });
    alt.appendChild(el("p", null, { class: "rmg-mid", text: "Sin clave puedes copiar el resumen del mes y pegarlo en un chat con Claude." }));
    var copiar = el("button", { marginTop: "10px" }, { class: "rmg-btn rmg-btn-soft", text: "Copiar resumen del mes" });
    copiar.addEventListener("click", function () {
      var payload = construirPrompt(estado.datos, estado.ym);
      var texto = SYS + "\n\nDatos del periodo:\n" + JSON.stringify(payload, null, 1);
      navigator.clipboard && navigator.clipboard.writeText(texto);
      copiar.textContent = "Copiado";
      setTimeout(function () { copiar.textContent = "Copiar resumen del mes"; }, 1800);
    });
    alt.appendChild(copiar);
    panel.appendChild(alt);
  }

  function renderPedir(panel) {
    var card = el("div", null, { class: "rmg-card", style: "text-align:center" });
    card.appendChild(el("p", null, { class: "rmg-mid", text: "Aún no hay revisión generada para este mes." }));
    var boton = el("button", { marginTop: "12px" }, { class: "rmg-btn rmg-btn-primary", text: "Generar revisión" });
    boton.addEventListener("click", async function () {
      card.innerHTML = "";
      card.appendChild(el("div", null, { class: "rmg-spin" }));
      card.appendChild(el("p", { textAlign: "center" }, { class: "rmg-mid", text: "Analizando el mes…" }));
      try {
        var resultado = await pedirRevision(estado.datos, estado.ym);
        estado.cache[estado.ym] = resultado;
        guardarCache(estado.cache);
        render();
      } catch (e) {
        card.innerHTML = "";
        card.appendChild(el("p", null, { class: "rmg-mid", text: "No se pudo generar: " + (e.message === "sin clave" ? "falta la clave de API." : "revisa tu conexión o la clave de API.") }));
        var reintentar = el("button", { marginTop: "10px" }, { class: "rmg-btn rmg-btn-soft", text: "Reintentar" });
        reintentar.addEventListener("click", function () { render(); });
        card.appendChild(reintentar);
      }
    });
    card.appendChild(boton);
    panel.appendChild(card);
  }

  function renderResultado(panel, r, cacheado) {
    var card = el("div", null, { class: "rmg-card" });
    card.appendChild(el("p", { fontFamily: "'Bricolage Grotesque',sans-serif", fontWeight: "700", fontSize: "16.5px" }, { text: r.titular || "" }));
    if (r.valoracion) card.appendChild(el("p", null, { class: "rmg-p", text: r.valoracion }));
    panel.appendChild(card);

    if (r.comparacion) {
      var card2 = el("div", null, { class: "rmg-card" });
      card2.appendChild(el("p", { fontWeight: "700", fontSize: "13.5px", marginBottom: "4px" }, { text: "Frente a meses anteriores" }));
      card2.appendChild(el("p", null, { class: "rmg-p", text: r.comparacion }));
      panel.appendChild(card2);
    }

    if (r.mejoras && r.mejoras.length) {
      var card3 = el("div", null, { class: "rmg-card" });
      card3.appendChild(el("p", { fontWeight: "700", fontSize: "13.5px" }, { text: "Mejoras" }));
      r.mejoras.forEach(function (m) {
        var li = el("div", null, { class: "rmg-li" });
        li.appendChild(el("div", null, { class: "rmg-dot" }));
        li.appendChild(el("div", null, { text: m }));
        card3.appendChild(li);
      });
      panel.appendChild(card3);
    }

    if (cacheado) {
      var regenerar = el("button", { marginTop: "14px" }, { class: "rmg-btn rmg-btn-soft", text: "Regenerar" });
      regenerar.addEventListener("click", function () {
        delete estado.cache[estado.ym];
        guardarCache(estado.cache);
        render();
      });
      panel.appendChild(regenerar);
    }
  }

  function init() {
    inyectarEstilos();
    var fab = el("button", null, { class: "rmg-fab", html: "✨ Revisión" });
    fab.addEventListener("click", abrirPanel);
    document.body.appendChild(fab);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
