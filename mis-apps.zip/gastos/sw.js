/* Service worker: guarda la app en el móvil para que abra sin internet.
   Los datos NO pasan por aquí: viven en localStorage, intactos entre versiones. */

const CACHE = "gastos-v2";
const ARCHIVOS = [
  "./",
  "./index.html",
  "./app.js",
  "./revision.js",
  "./manifest.json",
  "./icono-180.png",
  "./icono-192.png",
  "./icono-512.png",
];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ARCHIVOS)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((claves) => Promise.all(claves.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

/* Primero la red (para recibir actualizaciones), y si no hay, lo guardado */
self.addEventListener("fetch", (e) => {
  if (e.request.method !== "GET") return;
  e.respondWith(
    fetch(e.request)
      .then((resp) => {
        const copia = resp.clone();
        caches.open(CACHE).then((c) => c.put(e.request, copia)).catch(() => {});
        return resp;
      })
      .catch(() => caches.match(e.request).then((r) => r || caches.match("./index.html")))
  );
});
