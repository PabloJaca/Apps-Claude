/* Service worker del hub: solo cachea la pantalla de inicio.
   Cada app (gastos/salud) tiene su propio service worker independiente. */

const CACHE = "hub-v1";
const ARCHIVOS = ["./", "./index.html", "./manifest.json", "./icon-192.png", "./icon-512.png"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ARCHIVOS)));
  self.skipWaiting();
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE && k.startsWith("hub-")).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  // El hub solo gestiona sus propios archivos; todo lo de /gastos/ y /salud/
  // lo maneja el service worker de cada app.
  if (url.pathname.includes("/gastos/") || url.pathname.includes("/salud/")) return;
  e.respondWith(
    caches.match(e.request).then((r) => r || fetch(e.request))
  );
});
