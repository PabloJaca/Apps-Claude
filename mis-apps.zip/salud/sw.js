/* Service worker: la app entera funciona sin conexión.
   Solo las valoraciones de Claude necesitan internet. */

const CACHE = "salud-v1";
const SHELL = [
  "./",
  "./index.html",
  "./app.js",
  "./manifest.json",
  "./icon-192.png",
  "./icon-512.png",
  "./icon-maskable-512.png",
  "./apple-touch-icon.png",
  "./favicon-32.png",
];

self.addEventListener("install", (e) => {
  e.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((claves) => Promise.all(claves.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);

  // Nunca cacheamos las llamadas a la API
  if (url.hostname.endsWith("anthropic.com")) return;

  // Navegación: la app desde caché, y si no, red
  if (req.mode === "navigate") {
    e.respondWith(
      caches.match("./index.html").then((r) => r || fetch(req).catch(() => caches.match("./index.html")))
    );
    return;
  }

  // Resto: caché primero, y lo nuevo se guarda para la próxima
  e.respondWith(
    caches.match(req).then((cacheado) => {
      if (cacheado) return cacheado;
      return fetch(req)
        .then((res) => {
          if (res && res.status === 200 && (url.origin === self.location.origin || url.hostname.includes("fonts.g"))) {
            const copia = res.clone();
            caches.open(CACHE).then((c) => c.put(req, copia));
          }
          return res;
        })
        .catch(() => cacheado);
    })
  );
});
